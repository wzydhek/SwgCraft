namespace SwgCraft.Core;

public static class AppPaths
{
    static string AppData => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SwgCraft");
    public static string SettingsFile => Path.Combine(AppData, "settings.json");
    public static string DefaultDatabaseFile => Path.Combine(AppData, "swgcraft.db");
    public static string FeedCacheFolder => Path.Combine(AppData, "feedcache");
    /// <summary>Documents folder by default so the static JSON is easy to find and put under git.</summary>
    public static string DefaultStaticDataFolder =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SwgCraft", "data");
}

public sealed class AppSettings
{
    public int SchemaVersion { get; set; } = 1;
    public string StaticDataFolder { get; set; } = AppPaths.DefaultStaticDataFolder;
    public string DatabaseFile { get; set; } = AppPaths.DefaultDatabaseFile;
    public int? ActiveGalaxyId { get; set; }
    public string FeedUrlTemplate { get; set; } = "https://galaxyharvester.net/exports/current{galaxyId}.xml";
    public int MinSyncIntervalMinutes { get; set; } = 30;
    /// <summary>A feed smaller than this percentage of the currently active spawns aborts the sync.</summary>
    public int MinFeedPercentOfPrevious { get; set; } = 50;
    public PriceSettings Pricing { get; set; } = new();
    public List<string> DisabledProfessions { get; set; } = new();
    public bool IsProfessionEnabled(string professionId) =>
        !(DisabledProfessions?.Contains(professionId) ?? false);
}

public static class SettingsStore
{
    public static AppSettings Load(out string? error)
    {
        error = null;
        if (!File.Exists(AppPaths.SettingsFile)) return new AppSettings();
        try { return JsonFile.Read<AppSettings>(AppPaths.SettingsFile); }
        catch (Exception ex)
        {
            error = $"Could not read settings ({ex.Message}); using defaults.";
            return new AppSettings();
        }
    }

    public static void Save(AppSettings settings) => JsonFile.WriteAtomic(AppPaths.SettingsFile, settings);
}
