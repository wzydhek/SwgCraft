using System.Text.Json;

namespace SwgCraft.Core;

public sealed record LoadResult<T>(T Value, bool FileExisted, string? Error);
public sealed record SaveResult(bool Saved, IReadOnlyList<ValidationIssue> Issues);

/// <summary>Reads and writes the static JSON files (resources.json, professions.json).</summary>
public sealed class StaticDataStore
{
    public string Folder { get; }
    public string ResourcesPath => Path.Combine(Folder, "resources.json");
    public string ProfessionsPath => Path.Combine(Folder, "professions.json");

    public StaticDataStore(string folder) => Folder = folder;

    public LoadResult<ResourceTreeDocument> LoadResources() =>
        Load<ResourceTreeDocument>(ResourcesPath, d => d.SchemaVersion, ResourceTreeDocument.CurrentSchemaVersion);

    public LoadResult<ProfessionsDocument> LoadProfessions() =>
        Load<ProfessionsDocument>(ProfessionsPath, d => d.SchemaVersion, ProfessionsDocument.CurrentSchemaVersion);

    /// <summary>Refuses to write if there are validation errors, so the file on disk is always loadable.</summary>
    public SaveResult SaveResources(ResourceTreeDocument doc)
    {
        var issues = ResourceTreeValidator.Validate(doc);
        if (issues.Any(i => i.Severity == Severity.Error)) return new SaveResult(false, issues);
        doc.SchemaVersion = ResourceTreeDocument.CurrentSchemaVersion;
        JsonFile.WriteAtomic(ResourcesPath, doc);
        return new SaveResult(true, issues);
    }

    public SaveResult SaveProfessions(ProfessionsDocument doc)
    {
        var issues = ProfessionValidator.Validate(doc);
        if (issues.Any(i => i.Severity == Severity.Error)) return new SaveResult(false, issues);
        doc.SchemaVersion = ProfessionsDocument.CurrentSchemaVersion;
        JsonFile.WriteAtomic(ProfessionsPath, doc);
        return new SaveResult(true, issues);
    }

    static LoadResult<T> Load<T>(string path, Func<T, int> versionOf, int currentVersion) where T : new()
    {
        if (!File.Exists(path)) return new(new T(), false, null);
        try
        {
            var doc = JsonFile.Read<T>(path);
            if (versionOf(doc) > currentVersion)
                return new(new T(), true, $"{path} has schemaVersion {versionOf(doc)}, newer than this app understands.");
            return new(doc, true, null);
        }
        catch (Exception ex) when (ex is JsonException or IOException or InvalidDataException or UnauthorizedAccessException)
        {
            return new(new T(), true, $"Could not read {path}:\n{ex.Message}");
        }
    }
}
