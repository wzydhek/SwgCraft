using System.Text.RegularExpressions;

namespace SwgCraft.Core;

/// <summary>Persisted shape of professions.json. The order of the list is the order shown in dropdowns.</summary>
public sealed class ProfessionsDocument
{
    public const int CurrentSchemaVersion = 1;
    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public List<Profession> Professions { get; set; } = new();
}

public sealed class Profession
{
    /// <summary>Stable key that schematics will reference. Don't rename it once schematics use it.</summary>
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
}

/// <summary>Read-only lookup over a professions document.</summary>
public sealed class ProfessionCatalog
{
    public static ProfessionCatalog Empty { get; } = new(new ProfessionsDocument());

    readonly Dictionary<string, Profession> _byId = new(StringComparer.Ordinal);

    public ProfessionsDocument Document { get; }
    public IReadOnlyList<Profession> All => Document.Professions;

    public ProfessionCatalog(ProfessionsDocument document)
    {
        Document = document;
        foreach (var p in document.Professions)
            if (!string.IsNullOrEmpty(p.Id)) _byId.TryAdd(p.Id, p);
    }

    public Profession? Find(string id) => _byId.GetValueOrDefault(id);
}

public static class ProfessionValidator
{
    static readonly Regex IdPattern = new("^[a-z0-9_]+$", RegexOptions.Compiled);

    public static List<ValidationIssue> Validate(ProfessionsDocument doc)
    {
        var issues = new List<ValidationIssue>();
        var ids = new Dictionary<string, List<Profession>>(StringComparer.Ordinal);
        var names = new Dictionary<string, List<Profession>>(StringComparer.OrdinalIgnoreCase);

        void Add(Severity s, string code, string msg, Profession p) => issues.Add(new ValidationIssue(s, code, msg, p));

        if (doc.Professions.Count == 0)
            issues.Add(new ValidationIssue(Severity.Warning, "list.empty", "No professions are defined yet."));

        foreach (var p in doc.Professions)
        {
            var id = p.Id?.Trim() ?? "";
            var name = p.Name?.Trim() ?? "";

            if (id.Length == 0) Add(Severity.Error, "id.empty", $"'{(name.Length == 0 ? "(unnamed)" : name)}' has no ID.", p);
            else
            {
                if (!ids.TryGetValue(id, out var l)) ids[id] = l = new List<Profession>();
                l.Add(p);
                if (!IdPattern.IsMatch(id))
                    Add(Severity.Warning, "id.format", $"ID '{id}' should only use lowercase letters, digits and underscores.", p);
            }

            if (name.Length == 0) Add(Severity.Error, "name.empty", $"The profession with ID '{id}' has no name.", p);
            else
            {
                if (!names.TryGetValue(name, out var l)) names[name] = l = new List<Profession>();
                l.Add(p);
            }
        }

        foreach (var (id, list) in ids)
            if (list.Count > 1)
                foreach (var p in list) Add(Severity.Error, "id.duplicate", $"ID '{id}' is used by {list.Count} professions.", p);

        foreach (var (name, list) in names)
            if (list.Count > 1)
                foreach (var p in list) Add(Severity.Error, "name.duplicate", $"The name '{name}' is used by {list.Count} professions.", p);

        return issues;
    }
}
