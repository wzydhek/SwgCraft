using SwgCraft.Core;

namespace SwgCraft.Desktop;

public sealed class ProfessionVm : ObservableObject
{
    readonly ChangeTracker _t;
    string _id = "", _name = "";
    bool _enabled = true;

    public ProfessionVm(ChangeTracker t) => _t = t;

    /// <summary>New professions derive their ID from the name until the first save or a manual ID edit. Saved IDs never change by themselves.</summary>
    public bool IdFollowsName { get; set; }

    public string Name
    {
        get => _name;
        set
        {
            if (!Set(ref _name, value)) return;
            if (IdFollowsName) Set(ref _id, Slug.From(value), nameof(Id));
        }
    }

    public string Id
    {
        get => _id;
        set { if (Set(ref _id, value)) IdFollowsName = false; }
    }

    /// <summary>The "Include in builds" switch. It is a personal setting (settings.json), not part of professions.json.</summary>
    public bool Enabled { get => _enabled; set => Set(ref _enabled, value); }

    protected override void OnChanged() => _t.Touch();

    public static ProfessionVm CreateNew(ChangeTracker t)
    {
        var vm = new ProfessionVm(t) { IdFollowsName = true };
        vm.Name = "New Profession";
        return vm;
    }

    public static ProfessionVm FromModel(Profession p, bool enabled, ChangeTracker t) =>
        new(t) { _id = p.Id, _name = p.Name, _enabled = enabled };

    public Profession ToModel() => new() { Id = Id.Trim(), Name = Name.Trim() };
}
