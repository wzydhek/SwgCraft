using SwgCraft.Core;

namespace SwgCraft.Tests;

public sealed class ProfessionTests : IDisposable
{
    readonly string _folder = Path.Combine(Path.GetTempPath(), $"swgcraft-{Guid.NewGuid():N}");

    public void Dispose()
    {
        try { if (Directory.Exists(_folder)) Directory.Delete(_folder, true); } catch (IOException) { }
    }

    static ProfessionsDocument Doc(params (string Id, string Name)[] items)
    {
        var d = new ProfessionsDocument();
        foreach (var (id, name) in items) d.Professions.Add(new Profession { Id = id, Name = name });
        return d;
    }

    static bool Has(IEnumerable<ValidationIssue> issues, string code, Severity severity) =>
        issues.Any(i => i.Code == code && i.Severity == severity);

    // ------------------------------------------------------------ validator

    [Fact]
    public void A_normal_list_has_no_issues() =>
        Assert.Empty(ProfessionValidator.Validate(Doc(("armorsmith", "Armorsmith"), ("droid_engineer", "Droid Engineer"))));

    [Fact]
    public void Duplicate_ids_are_errors() =>
        Assert.True(Has(ProfessionValidator.Validate(Doc(("chef", "Chef"), ("chef", "Cook"))), "id.duplicate", Severity.Error));

    [Fact]
    public void Duplicate_names_are_errors_ignoring_case() =>
        Assert.True(Has(ProfessionValidator.Validate(Doc(("a", "Chef"), ("b", "chef"))), "name.duplicate", Severity.Error));

    [Fact]
    public void Empty_id_or_name_is_an_error()
    {
        Assert.True(Has(ProfessionValidator.Validate(Doc(("", "Chef"))), "id.empty", Severity.Error));
        Assert.True(Has(ProfessionValidator.Validate(Doc(("chef", "  "))), "name.empty", Severity.Error));
    }

    [Fact]
    public void Odd_ids_are_only_a_warning()
    {
        var issues = ProfessionValidator.Validate(Doc(("Droid Engineer", "Droid Engineer")));
        Assert.True(Has(issues, "id.format", Severity.Warning));
        Assert.DoesNotContain(issues, i => i.Severity == Severity.Error);
    }

    [Fact]
    public void An_empty_list_is_only_a_warning()
    {
        var issues = ProfessionValidator.Validate(Doc());
        Assert.True(Has(issues, "list.empty", Severity.Warning));
        Assert.DoesNotContain(issues, i => i.Severity == Severity.Error);
    }

    [Fact]
    public void Issues_point_at_the_profession_they_belong_to()
    {
        var doc = Doc(("a", "Chef"), ("b", "chef"));
        var issues = ProfessionValidator.Validate(doc);
        var subjects = issues.Where(i => i.Code == "name.duplicate").Select(i => i.Subject).ToList();
        Assert.Contains(doc.Professions[0], subjects);
        Assert.Contains(doc.Professions[1], subjects);
    }

    // ------------------------------------------------------------ catalog

    [Fact]
    public void Catalog_keeps_order_and_finds_by_id()
    {
        var catalog = new ProfessionCatalog(Doc(("tailor", "Tailor"), ("chef", "Chef"), ("architect", "Architect")));
        Assert.Equal(new[] { "tailor", "chef", "architect" }, catalog.All.Select(p => p.Id).ToArray());
        Assert.Equal("Chef", catalog.Find("chef")!.Name);
        Assert.Null(catalog.Find("nobody"));
        Assert.Empty(ProfessionCatalog.Empty.All);
    }

    // ------------------------------------------------------------ files

    [Fact]
    public void Save_and_load_round_trip_in_order()
    {
        var store = new StaticDataStore(_folder);
        var saved = store.SaveProfessions(Doc(("droid_engineer", "Droid Engineer"), ("chef", "Chef")));
        Assert.True(saved.Saved);
        Assert.True(File.Exists(store.ProfessionsPath));

        var text = File.ReadAllText(store.ProfessionsPath);
        Assert.Contains("\"professions\"", text);
        Assert.Contains("\"droid_engineer\"", text);

        var load = store.LoadProfessions();
        Assert.Null(load.Error);
        Assert.True(load.FileExisted);
        Assert.Equal(new[] { "droid_engineer", "chef" }, load.Value.Professions.Select(p => p.Id).ToArray());
        Assert.Equal("Droid Engineer", load.Value.Professions[0].Name);
    }

    [Fact]
    public void Saving_with_errors_writes_nothing()
    {
        var store = new StaticDataStore(_folder);
        var result = store.SaveProfessions(Doc(("a", "Chef"), ("a", "Tailor")));
        Assert.False(result.Saved);
        Assert.False(File.Exists(store.ProfessionsPath));
    }

    [Fact]
    public void A_missing_file_loads_as_an_empty_list_without_error()
    {
        var load = new StaticDataStore(_folder).LoadProfessions();
        Assert.False(load.FileExisted);
        Assert.Null(load.Error);
        Assert.Empty(load.Value.Professions);
    }

    [Fact]
    public void A_misspelled_property_is_an_error_instead_of_being_ignored()
    {
        Directory.CreateDirectory(_folder);
        var store = new StaticDataStore(_folder);
        File.WriteAllText(store.ProfessionsPath, """{ "schemaVersion": 1, "profession": [ { "id": "chef", "name": "Chef" } ] }""");
        Assert.NotNull(store.LoadProfessions().Error);
    }

    [Fact]
    public void A_newer_schema_version_is_refused()
    {
        Directory.CreateDirectory(_folder);
        var store = new StaticDataStore(_folder);
        File.WriteAllText(store.ProfessionsPath, """{ "schemaVersion": 99, "professions": [] }""");
        Assert.NotNull(store.LoadProfessions().Error);
    }

    [Fact]
    public void Resources_still_load_and_save_after_the_store_refactor()
    {
        var store = new StaticDataStore(_folder);
        var leaf = new ResourceNode
        {
            Id = "steel", Name = "Steel",
            ExternalIds = new() { [ExternalSources.GalaxyHarvester] = "steel_gh" },
            Ranges = new() { [Stat.OQ] = new StatRange { Min = 1, Max = 1000 } },
        };
        Assert.True(store.SaveResources(new ResourceTreeDocument { Nodes = { leaf } }).Saved);
        var load = store.LoadResources();
        Assert.Null(load.Error);
        Assert.Equal("steel", Assert.Single(load.Value.Nodes).Id);
    }

    // ------------------------------------------------------------ settings and ids

    [Fact]
    public void Professions_are_enabled_unless_listed_as_disabled()
    {
        var s = new AppSettings();
        Assert.True(s.IsProfessionEnabled("chef"));
        s.DisabledProfessions.Add("chef");
        Assert.False(s.IsProfessionEnabled("chef"));
        Assert.True(s.IsProfessionEnabled("tailor"));
    }

    [Fact]
    public void Old_settings_files_without_the_property_still_load()
    {
        var path = Path.Combine(Path.GetTempPath(), $"swgcraft-{Guid.NewGuid():N}.json");
        try
        {
            File.WriteAllText(path, """{ "schemaVersion": 1 }""");
            var s = JsonFile.Read<AppSettings>(path);
            Assert.Empty(s.DisabledProfessions);
            Assert.True(s.IsProfessionEnabled("chef"));

            s.DisabledProfessions.Add("chef");
            JsonFile.WriteAtomic(path, s);
            Assert.False(JsonFile.Read<AppSettings>(path).IsProfessionEnabled("chef"));
        }
        finally { File.Delete(path); File.Delete(path + ".bak"); }
    }

    [Fact]
    public void Names_become_ids()
    {
        Assert.Equal("droid_engineer", Slug.From("Droid Engineer"));
        Assert.Equal("bio_engineer", Slug.From("Bio-Engineer"));
    }
}
