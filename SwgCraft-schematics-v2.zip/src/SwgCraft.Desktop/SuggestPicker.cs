using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Threading;

namespace SwgCraft.Desktop;

/// <summary>
/// An editable combo box that filters its list as you type: every word typed has to appear somewhere in the entry
/// (case-insensitive), so "scope adv" finds "Class: Advanced Weapon Scope". Pick with the mouse, the arrow keys + Enter,
/// or just type the whole name (or enough of it that only one entry is left) and press Enter/Tab.
/// </summary>
public sealed class SuggestComboBox : ComboBox
{
    readonly IReadOnlyList<RefOption> _all;
    readonly ListCollectionView _view;
    string[] _words = Array.Empty<string>();
    TextBox? _tb;
    bool _busy;

    public static readonly DependencyProperty KeyProperty = DependencyProperty.Register(
        nameof(Key), typeof(string), typeof(SuggestComboBox),
        new FrameworkPropertyMetadata("", (d, e) => ((SuggestComboBox)d).OnKeyChanged((string?)e.NewValue ?? "")));

    /// <summary>The key of the chosen option ("" for none). Bind this, not SelectedValue.</summary>
    public string Key
    {
        get => (string)GetValue(KeyProperty);
        set => SetValue(KeyProperty, value);
    }

    public SuggestComboBox(IReadOnlyList<RefOption> options)
    {
        _all = options;
        _view = new ListCollectionView(options.ToList());   // our own view, so filtering never affects other pickers
        _view.Filter = Match;
        IsEditable = true;
        IsTextSearchEnabled = false;
        StaysOpenOnEdit = true;
        DisplayMemberPath = nameof(RefOption.Display);
        ItemsSource = _view;
    }

    public override void OnApplyTemplate()
    {
        base.OnApplyTemplate();
        if (_tb != null) _tb.TextChanged -= OnTextChanged;
        _tb = GetTemplateChild("PART_EditableTextBox") as TextBox;
        if (_tb != null) _tb.TextChanged += OnTextChanged;
    }

    bool Match(object o)
    {
        var display = ((RefOption)o).Display;
        foreach (var w in _words)
            if (display.IndexOf(w, StringComparison.OrdinalIgnoreCase) < 0) return false;
        return true;
    }

    void OnKeyChanged(string key)
    {
        _busy = true;
        try { SelectedItem = key.Length == 0 ? null : _all.FirstOrDefault(o => o.Key == key); }
        finally { _busy = false; }
    }

    void OnTextChanged(object sender, TextChangedEventArgs e)
    {
        if (_busy || _tb == null) return;
        var text = _tb.Text ?? "";
        if (SelectedItem is RefOption sel && sel.Display == text) return;   // the text came from picking an entry, not from typing

        _busy = true;
        try
        {
            int caret = _tb.CaretIndex;
            _words = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            _view.Refresh();                       // may clear the selection, which can wipe the text, so put it back
            _tb.Text = text;
            _tb.CaretIndex = Math.Min(caret, text.Length);
        }
        finally { _busy = false; }

        IsDropDownOpen = _view.Count > 0;
    }

    /// <summary>The key the user ended up with, or null if the text matches nothing (the caller then keeps the old value).</summary>
    public string? ResolveKey()
    {
        var text = (_tb?.Text ?? Text ?? "").Trim();
        if (SelectedItem is RefOption sel && sel.Display == text) return sel.Key;
        if (text.Length == 0) return null;
        var exact = _all.FirstOrDefault(o => string.Equals(o.Display, text, StringComparison.OrdinalIgnoreCase));
        if (exact != null) return exact.Key;
        if (_view.Count == 1) return ((RefOption)_view.GetItemAt(0)).Key;   // only one entry left after filtering
        return null;
    }

    public void FocusForEditing()
    {
        Dispatcher.BeginInvoke(new Action(() =>
        {
            ApplyTemplate();
            _tb?.Focus();
            _tb?.SelectAll();
            IsDropDownOpen = true;
        }), DispatcherPriority.Input);
    }
}

/// <summary>A grid column showing the display text of a stored key and editing it with a <see cref="SuggestComboBox"/>.</summary>
public sealed class PickerColumn : DataGridColumn
{
    sealed class KeyToDisplay : IValueConverter
    {
        readonly PickerColumn _owner;
        public KeyToDisplay(PickerColumn owner) => _owner = owner;

        public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        {
            var key = value as string ?? "";
            if (key.Length == 0) return "(choose...)";
            return _owner._display.TryGetValue(key, out var d) ? d : key;   // an unknown key is shown as it is, so a dangling reference is visible
        }

        public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
            throw new NotSupportedException();
    }

    readonly string _path;
    readonly KeyToDisplay _converter;
    Dictionary<string, string> _display = new(StringComparer.Ordinal);
    IReadOnlyList<RefOption> _options = Array.Empty<RefOption>();

    /// <param name="path">The view-model property holding the stored key.</param>
    public PickerColumn(string header, string path)
    {
        Header = header;
        _path = path;
        _converter = new KeyToDisplay(this);
        Width = new DataGridLength(1, DataGridLengthUnitType.Star);
    }

    public void SetOptions(IReadOnlyList<RefOption> options)
    {
        _options = options;
        var map = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var o in options) map.TryAdd(o.Key, o.Display);
        _display = map;
    }

    protected override FrameworkElement GenerateElement(DataGridCell cell, object dataItem)
    {
        var tb = new TextBlock { Margin = new Thickness(4, 2, 4, 2), VerticalAlignment = VerticalAlignment.Center };
        tb.SetBinding(TextBlock.TextProperty, new Binding(_path) { Converter = _converter, Mode = BindingMode.OneWay });
        return tb;
    }

    protected override FrameworkElement GenerateEditingElement(DataGridCell cell, object dataItem)
    {
        var cb = new SuggestComboBox(_options);
        // Explicit: nothing is written back until the cell is committed, so Esc really cancels.
        cb.SetBinding(SuggestComboBox.KeyProperty,
            new Binding(_path) { Mode = BindingMode.TwoWay, UpdateSourceTrigger = UpdateSourceTrigger.Explicit });
        return cb;
    }

    protected override object PrepareCellForEdit(FrameworkElement editingElement, RoutedEventArgs editingEventArgs)
    {
        if (editingElement is SuggestComboBox cb)
        {
            cb.FocusForEditing();
            return cb.Key;
        }
        return "";
    }

    protected override bool CommitCellEdit(FrameworkElement editingElement)
    {
        if (editingElement is SuggestComboBox cb)
        {
            var key = cb.ResolveKey();
            if (key != null)
            {
                cb.Key = key;
                BindingOperations.GetBindingExpression(cb, SuggestComboBox.KeyProperty)?.UpdateSource();
            }
        }
        return true;
    }
}
