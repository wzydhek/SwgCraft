namespace SwgCraft.Core;

/// <summary>Grades a stat against the maximum its resource type can have (used for the green highlighting).</summary>
public static class StatQuality
{
    public const int HighPercent = 90;   // light green
    public const int TopPercent = 95;    // darker green

    /// <summary>0 = no highlight, 1 = at least 90% of max, 2 = at least 95% of max.</summary>
    public static int Tier(int value, int max)
    {
        if (max <= 0) return 0;
        long scaled = (long)value * 100;
        if (scaled >= (long)max * TopPercent) return 2;
        if (scaled >= (long)max * HighPercent) return 1;
        return 0;
    }
}
