using SwgCraft.Core;

namespace SwgCraft.Data;

/// <summary>Works out the default price per unit (CPU) for a resource when it is first added to inventory.</summary>
public interface IUnitPriceCalculator
{
    /// <summary>Returns null when no price can be worked out; the price is then left blank for you to enter.</summary>
    double? Calculate(Spawn spawn, ResourceNode? resourceType);
}

/// <summary>Placeholder until the real formulas are in: always leaves the price blank.</summary>
public sealed class BlankPriceCalculator : IUnitPriceCalculator
{
    public double? Calculate(Spawn spawn, ResourceNode? resourceType) => null;
}

public static class UnitPricing
{
    public static IUnitPriceCalculator Calculator { get; set; } = new BlankPriceCalculator();
}
