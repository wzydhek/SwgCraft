using System.Text.Json;

namespace SwgCraft.Core;

public sealed record LoadResult<T>(T Value, bool FileExisted, string? Error);
public sealed record SaveResult(bool Saved, IReadOnlyList<ValidationIssue> Issues);

/// <summary>Reads and writes the static JSON files. Only resources.json exists so far.</summary>
public sealed class StaticDataStore
{
    public string Folder { get; }
    public string ResourcesPath => Path.Combine(Folder, "resources.json");

    public StaticDataStore(string folder) => Folder = folder;

    public LoadResult<ResourceTreeDocument> LoadResources()
    {
        if (!File.Exists(ResourcesPath))
            return new(new ResourceTreeDocument(), false, null);
        try
        {
            var doc = JsonFile.Read<ResourceTreeDocument>(ResourcesPath);
            if (doc.SchemaVersion > ResourceTreeDocument.CurrentSchemaVersion)
                return new(new ResourceTreeDocument(), true,
                    $"{ResourcesPath} has schemaVersion {doc.SchemaVersion}, newer than this app understands.");
            return new(doc, true, null);
        }
        catch (Exception ex) when (ex is JsonException or IOException or InvalidDataException or UnauthorizedAccessException)
        {
            return new(new ResourceTreeDocument(), true, $"Could not read {ResourcesPath}:\n{ex.Message}");
        }
    }

    /// <summary>Refuses to write if there are validation errors, so the file on disk is always loadable.</summary>
    public SaveResult SaveResources(ResourceTreeDocument doc)
    {
        var issues = ResourceTreeValidator.Validate(doc);
        if (issues.Any(i => i.Severity == Severity.Error)) return new SaveResult(false, issues);
        doc.SchemaVersion = ResourceTreeDocument.CurrentSchemaVersion;
        JsonFile.WriteAtomic(ResourcesPath, doc);
        return new SaveResult(true, issues);
    }
}
