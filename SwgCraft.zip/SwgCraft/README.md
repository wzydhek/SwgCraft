# SWG Craft Planner (work in progress)

Static data lives in JSON files, spawn data in SQLite. This first slice contains:

* **Resource tree**: JSON model, validator, and an editor window (tree, stat ranges per leaf, SWGEmu + Galaxy Harvester IDs).
* **SQLite spawn database**: galaxy-scoped spawns, planets, inventory table (schema only), sync log, migrations.
* **Galaxy Harvester feed**: XML parser (MA -> MB translation), sync with safety checks, optional XML file import.
* **Desktop shell**: main window with menus, galaxy selector, sync buttons; spawn browser; galaxy manager.

## Build and run

```
cd SwgCraft
dotnet new sln -n SwgCraft
dotnet sln add src/SwgCraft.Core src/SwgCraft.Data src/SwgCraft.Desktop tests/SwgCraft.Tests
dotnet test
dotnet run --project src/SwgCraft.Desktop      # Windows only (WPF)
```

Target framework is set once in `Directory.Build.props` (`TfmBase`, currently `net8.0`).
This code was written without access to a .NET SDK, so it has not been compiled or run yet.
Expect to fix a handful of compile errors on the first build, and run `dotnet test` first.

## Where things are stored

| What | Where |
|---|---|
| `resources.json` (static data) | `Documents\SwgCraft\data` (change in settings.json, `staticDataFolder`) |
| `settings.json`, `swgcraft.db`, feed cache | `%AppData%\SwgCraft` |

## First-run workflow

1. Resources > Manage Galaxies: add your galaxy ID (118 in `current118.xml`).
2. Static Data > Resource Tree Editor: enter the tree. For every leaf, fill in the Galaxy Harvester `resource_type id` (that is how spawns are matched) and the stat ranges.
3. Save (blocked while validation errors exist; warnings are fine), then Sync Feed or import a saved XML file in the Spawn Browser.

## Sync rules (galaxy + name identity)

* Matching key is `(galaxy, name)` among current spawns. Same type and same `enter_date` means the same spawn; changed stats are treated as a source correction and updated in place.
* Same name with a different type or `enter_date` closes the old row and inserts a new one, so inventory stays attached to the old spawn.
* A despawned row with identical name, type and `enter_date` is reopened rather than duplicated.
* Current spawns missing from the feed are marked despawned, unless the feed is empty or below `minFeedPercentOfPrevious` of the active count; then nothing changes and you are asked whether to apply it anyway.
* Spawns whose GH type is not mapped in the tree are skipped and counted, never inserted with a bad type.
* Everything for one sync runs in a single transaction.

## Not built yet

Schematics, component classes, looted items, professions, inventory UI, JSON Schema files, the BOM planner.
