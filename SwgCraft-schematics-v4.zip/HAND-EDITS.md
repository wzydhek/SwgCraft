# Looted items, component classes, schematics

Everything here is new files plus a replacement `StaticDataStore.cs` (it keeps every member the old one had).
Copy the `src` and `tests` folders over your solution, then make the one hand edit below.
No edits to `Services.cs` or `Settings.cs` are needed.

## MainWindow.xaml: add four items to the Static Data menu

```xml
<MenuItem Header="C_ategories..." Click="Categories_Click"/>
<MenuItem Header="_Looted Items..." Click="LootItems_Click"/>
<MenuItem Header="_Component Classes..." Click="Classes_Click"/>
<MenuItem Header="_Schematics..." Click="Schematics_Click"/>
```

## MainWindow.xaml.cs: add the fields and handlers inside the class

```csharp
CategoryEditorWindow? _categoryEditor;
LootItemEditorWindow? _lootEditor;
ClassEditorWindow? _classEditor;
SchematicEditorWindow? _schematicEditor;

void Categories_Click(object sender, RoutedEventArgs e)
{
    if (_categoryEditor != null) { _categoryEditor.Activate(); return; }
    var w = new CategoryEditorWindow { Owner = this };
    w.Closed += (_, _) => _categoryEditor = null;
    _categoryEditor = w;
    w.Show();
}

void LootItems_Click(object sender, RoutedEventArgs e)
{
    if (_lootEditor != null) { _lootEditor.Activate(); return; }
    var w = new LootItemEditorWindow { Owner = this };
    w.Closed += (_, _) => _lootEditor = null;
    _lootEditor = w;
    w.Show();
}

void Classes_Click(object sender, RoutedEventArgs e)
{
    if (_classEditor != null) { _classEditor.Activate(); return; }
    var w = new ClassEditorWindow { Owner = this };
    w.Closed += (_, _) => _classEditor = null;
    _classEditor = w;
    w.Show();
}

void Schematics_Click(object sender, RoutedEventArgs e)
{
    if (_schematicEditor != null) { _schematicEditor.Activate(); return; }
    var w = new SchematicEditorWindow { Owner = this };
    w.Closed += (_, _) => _schematicEditor = null;
    _schematicEditor = w;
    w.Show();
}
```

## Categories

The schematic's Category is now a pick from `categories.json` (type to search; clear the box for none), stored as the category's ID.
If you already typed categories into schematics, open Static Data > Categories and press **Import from schematics**: it adds one category per distinct value.
Then open the schematic editor: values that match a category's name are switched to its ID automatically, and you just Save.
Any schematic whose category is not in the list is refused on save, with the reason in the issue list.

## Order of data entry

Classes list schematics and schematics use classes, and each editor checks references against what is saved on disk.
So: save looted items, then the base schematics (the ones that need no classes), then the classes, then the schematics that use those classes.
Each editor re-reads the other lists when you switch back to its window, so the pickers update without reopening it.

## New files in the static data folder

`lootitems.json`, `componentclasses.json`, `schematics.json`, `categories.json`.
