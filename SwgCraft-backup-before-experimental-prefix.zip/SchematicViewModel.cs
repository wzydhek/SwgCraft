using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using SwgCraft.Core;

namespace SwgCraft.Desktop;

public sealed class ProfessionPickVm : ObservableObject
{
    readonly ChangeTracker _t;
    bool _isSelected;

    public ProfessionPickVm(string id, string name, bool selected, ChangeTracker t)
    {
        Id = id; Name = name; _isSelected = selected; _t = t;
    }

    public string Id { get; }
    public string Name { get; }
    public bool IsSelected { get => _isSelected; set => Set(ref _isSelected, value); }

    protected override void OnChanged() => _t.Touch();
}

public sealed class ComponentSlotVm : ObservableObject
{
    public const string SchematicPrefix = "schematic:";
    public const string ClassPrefix = "class:";

    readonly ChangeTracker _t;
    string _key = "";
    int _quantity = 1;
    bool _identical, _optional;

    public ComponentSlotVm(ChangeTracker t) => _t = t;

    public static string KeyFor(SlotKind kind, string id) => (kind == SlotKind.Class ? ClassPrefix : SchematicPrefix) + id;

    /// <summary>"schematic:id" or "class:id". A null write (a picker losing its list) is ignored so a refresh can't wipe the choice.</summary>
    public string Key { get => _key; set { if (value != null) Set(ref _key, value); } }
    public void RaiseKey() => Raise(nameof(Key));

    public int Quantity { get => _quantity; set => Set(ref _quantity, value); }
    public bool Identical { get => _identical; set => Set(ref _identical, value); }
    public bool Optional { get => _optional; set => Set(ref _optional, value); }

    protected override void OnChanged() => _t.Touch();

    public static ComponentSlotVm FromModel(ComponentSlot m, ChangeTracker t) => new(t)
    {
        _key = KeyFor(m.Kind, m.Target), _quantity = m.Quantity, _identical = m.Identical, _optional = m.Optional
    };

    public ComponentSlot ToModel()
    {
        bool isClass = _key.StartsWith(ClassPrefix, StringComparison.Ordinal);
        string id = isClass ? _key[ClassPrefix.Length..]
                  : _key.StartsWith(SchematicPrefix, StringComparison.Ordinal) ? _key[SchematicPrefix.Length..]
                  : "";
        return new ComponentSlot
        {
            Kind = isClass ? SlotKind.Class : SlotKind.Schematic,
            Target = id, Quantity = _quantity, Identical = _identical, Optional = _optional
        };
    }
}

public sealed class ResourceSlotVm : ObservableObject
{
    readonly ChangeTracker _t;
    string _resource = "";
    int _amount = 1;

    public ResourceSlotVm(ChangeTracker t) => _t = t;

    /// <summary>Resource-tree node ID. A null write (a picker losing its list) is ignored so a refresh can't wipe the choice.</summary>
    public string Resource { get => _resource; set { if (value != null) Set(ref _resource, value); } }
    public void RaiseResource() => Raise(nameof(Resource));

    public int Amount { get => _amount; set => Set(ref _amount, value); }

    protected override void OnChanged() => _t.Touch();

    public static ResourceSlotVm FromModel(ResourceSlot m, ChangeTracker t) => new(t) { _resource = m.Resource, _amount = m.Amount };
    public ResourceSlot ToModel() => new() { Resource = _resource, Amount = _amount };
}

/// <summary>
/// One modifier of an experimental (Charges, Effective Range, ...). The eleven stat properties are what the grid binds to;
/// a blank cell is 0 and is not saved.
/// </summary>
public sealed class ModifierVm : ObservableObject
{
    readonly ChangeTracker _t;
    readonly int[] _w = new int[StatInfo.All.Count];
    string _name = "";

    public ModifierVm(ChangeTracker t) => _t = t;

    public string Name { get => _name; set => Set(ref _name, value); }

    int? Get(Stat s) { var v = _w[(int)s]; return v == 0 ? null : v; }

    void Put(Stat s, int? v, string property)
    {
        int nv = v ?? 0;
        if (_w[(int)s] == nv) return;
        _w[(int)s] = nv;
        Raise(property);
        Raise(nameof(Total));
        Raise(nameof(TotalOk));
        OnChanged();
    }

    public int? ER { get => Get(Stat.ER); set => Put(Stat.ER, value, nameof(ER)); }
    public int? CR { get => Get(Stat.CR); set => Put(Stat.CR, value, nameof(CR)); }
    public int? CD { get => Get(Stat.CD); set => Put(Stat.CD, value, nameof(CD)); }
    public int? DR { get => Get(Stat.DR); set => Put(Stat.DR, value, nameof(DR)); }
    public int? FL { get => Get(Stat.FL); set => Put(Stat.FL, value, nameof(FL)); }
    public int? HR { get => Get(Stat.HR); set => Put(Stat.HR, value, nameof(HR)); }
    public int? MB { get => Get(Stat.MB); set => Put(Stat.MB, value, nameof(MB)); }
    public int? PE { get => Get(Stat.PE); set => Put(Stat.PE, value, nameof(PE)); }
    public int? OQ { get => Get(Stat.OQ); set => Put(Stat.OQ, value, nameof(OQ)); }
    public int? SR { get => Get(Stat.SR); set => Put(Stat.SR, value, nameof(SR)); }
    public int? UT { get => Get(Stat.UT); set => Put(Stat.UT, value, nameof(UT)); }

    public int Total => _w.Sum();
    public bool TotalOk => Total == 100;

    protected override void OnChanged() => _t.Touch();

    public static ModifierVm FromModel(ExperimentModifier m, ChangeTracker t)
    {
        var vm = new ModifierVm(t) { _name = m.Name };
        foreach (var (stat, w) in m.Weights) vm._w[(int)stat] = w;
        return vm;
    }

    public ExperimentModifier ToModel()
    {
        var e = new ExperimentModifier { Name = _name.Trim() };
        foreach (var stat in StatInfo.All)
            if (_w[(int)stat] != 0) e.Weights[stat] = _w[(int)stat];
        return e;
    }
}

/// <summary>
/// One experimental (what experimentation points are spent on) and the modifiers it raises.
/// While it has exactly one modifier whose name matches its own, renaming the experimental renames that modifier too.
/// </summary>
public sealed class ExperimentVm : ObservableObject
{
    readonly ChangeTracker _t;
    string _name = "";
    SortedDictionary<Stat, int>? _legacyWeights;   // only if the file had both old percentages and modifiers; kept so nothing is lost

    public ExperimentVm(ChangeTracker t)
    {
        _t = t;
        Modifiers.CollectionChanged += ModifiersChanged;
    }

    /// <summary>A new experimental with one modifier of the same name, which is the usual case.</summary>
    public static ExperimentVm CreateNew(ChangeTracker t)
    {
        var vm = new ExperimentVm(t);
        vm.Modifiers.Add(new ModifierVm(t));
        return vm;
    }

    public ObservableCollection<ModifierVm> Modifiers { get; } = new();

    public string Name
    {
        get => _name;
        set
        {
            var old = _name;
            if (!Set(ref _name, value)) return;
            if (Modifiers.Count == 1 && (Modifiers[0].Name ?? "").Trim() == (old ?? "").Trim()) Modifiers[0].Name = value;
        }
    }

    /// <summary>The modifier names, for the experimentals grid.</summary>
    public string Summary => Modifiers.Count == 0 ? "(no modifiers)" : string.Join(", ", Modifiers.Select(m => string.IsNullOrWhiteSpace(m.Name) ? "(unnamed)" : m.Name.Trim()));

    /// <summary>False if there are no modifiers or any modifier's percentages don't total 100.</summary>
    public bool AllOk => Modifiers.Count > 0 && Modifiers.All(m => m.TotalOk);

    void ModifiersChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        if (e.OldItems != null) foreach (ModifierVm m in e.OldItems) m.PropertyChanged -= ModifierPropertyChanged;
        if (e.NewItems != null) foreach (ModifierVm m in e.NewItems) m.PropertyChanged += ModifierPropertyChanged;
        RaiseSummary();
        _t.Touch();
    }

    void ModifierPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(ModifierVm.Name) or nameof(ModifierVm.TotalOk)) RaiseSummary();
    }

    void RaiseSummary()
    {
        Raise(nameof(Summary));
        Raise(nameof(AllOk));
    }

    protected override void OnChanged() => _t.Touch();

    public static ExperimentVm FromModel(Experiment m, ChangeTracker t)
    {
        var vm = new ExperimentVm(t) { _name = m.Name, _legacyWeights = m.LegacyWeights };
        foreach (var mod in m.Modifiers) vm.Modifiers.Add(ModifierVm.FromModel(mod, t));
        return vm;
    }

    public Experiment ToModel()
    {
        var e = new Experiment { Name = _name.Trim(), LegacyWeights = _legacyWeights };
        foreach (var mod in Modifiers) e.Modifiers.Add(mod.ToModel());
        return e;
    }
}

public sealed class SchematicVm : ObservableObject
{
    readonly ChangeTracker _t;
    string _id = "", _name = "", _category = "";
    int? _complexity, _size;
    int _showIndex;                       // 0 = default, 1 = yes, 2 = no
    List<string> _extraProfessions = new();   // IDs not in the current profession list; kept so nothing is lost silently

    public SchematicVm(ChangeTracker t)
    {
        _t = t;
        Components.CollectionChanged += Touch;
        Resources.CollectionChanged += Touch;
        Experiments.CollectionChanged += Touch;
    }

    void Touch(object? sender, NotifyCollectionChangedEventArgs e) => _t.Touch();

    public ObservableCollection<ProfessionPickVm> Professions { get; } = new();
    public ObservableCollection<ComponentSlotVm> Components { get; } = new();
    public ObservableCollection<ResourceSlotVm> Resources { get; } = new();
    public ObservableCollection<ExperimentVm> Experiments { get; } = new();

    /// <summary>New schematics derive their ID from the name until the first save or a manual ID edit. Saved IDs never change by themselves.</summary>
    public bool IdFollowsName { get; set; }

    public string Name
    {
        get => _name;
        set
        {
            if (!Set(ref _name, value)) return;
            if (IdFollowsName) Set(ref _id, Slug.From(value), nameof(Id));
        }
    }

    public string Id
    {
        get => _id;
        set { if (Set(ref _id, value)) IdFollowsName = false; }
    }

    public string Category { get => _category; set => Set(ref _category, value); }
    public int? Complexity { get => _complexity; set => Set(ref _complexity, value); }
    public int? Size { get => _size; set => Set(ref _size, value); }
    public int ShowIndex { get => _showIndex; set => Set(ref _showIndex, value); }

    protected override void OnChanged() => _t.Touch();

    // ------------------------------------------------------------ category

    /// <summary>
    /// Older data may hold a category's name (or a different capitalisation of its ID) instead of its ID. Switches such a value to the real ID
    /// without marking the schematic as edited; a value that matches nothing is left alone so validation can point it out.
    /// </summary>
    public void ResolveCategory(IReadOnlyList<CraftCategory> categories)
    {
        var c = (_category ?? "").Trim();
        if (c.Length == 0 || categories.Any(x => x.Id == c)) return;
        var match = categories.FirstOrDefault(x => string.Equals(x.Name?.Trim(), c, StringComparison.OrdinalIgnoreCase))
                    ?? categories.FirstOrDefault(x => string.Equals(x.Id, c, StringComparison.OrdinalIgnoreCase));
        if (match == null) return;
        _category = match.Id;
        Raise(nameof(Category));
    }

    // ------------------------------------------------------------ professions

    public IEnumerable<string> SelectedProfessionIds() =>
        Professions.Where(p => p.IsSelected).Select(p => p.Id).Concat(_extraProfessions);

    /// <summary>Rebuilds the profession check boxes from the catalog, keeping what is ticked (IDs not in the catalog are kept aside).</summary>
    public void SetProfessionCatalog(IReadOnlyList<Profession> catalog)
    {
        var wanted = SelectedProfessionIds().ToList();
        var chosen = new HashSet<string>(wanted, StringComparer.Ordinal);
        Professions.Clear();
        var known = new HashSet<string>(StringComparer.Ordinal);
        foreach (var p in catalog)
        {
            if (string.IsNullOrEmpty(p.Id) || !known.Add(p.Id)) continue;
            Professions.Add(new ProfessionPickVm(p.Id, p.Name, chosen.Contains(p.Id), _t));
        }
        _extraProfessions = wanted.Where(id => !known.Contains(id)).Distinct(StringComparer.Ordinal).ToList();
        Raise(nameof(UnknownProfessions));
    }

    /// <summary>Profession IDs this schematic lists that no longer exist, shown so the user can see why validation complains.</summary>
    public string UnknownProfessions => _extraProfessions.Count == 0 ? "" : "Unknown professions: " + string.Join(", ", _extraProfessions);

    // ------------------------------------------------------------ conversion

    public static SchematicVm CreateNew(ChangeTracker t, IReadOnlyList<Profession> catalog)
    {
        var vm = new SchematicVm(t) { IdFollowsName = true };
        vm.SetProfessionCatalog(catalog);
        vm.Name = "New Schematic";
        return vm;
    }

    public static SchematicVm FromModel(Schematic m, IReadOnlyList<Profession> catalog, ChangeTracker t)
    {
        var vm = new SchematicVm(t)
        {
            _id = m.Id, _name = m.Name, _category = m.Category ?? "", _complexity = m.Complexity, _size = m.Size,
            _showIndex = m.ShowOverride == null ? 0 : m.ShowOverride.Value ? 1 : 2,
            _extraProfessions = m.Professions.ToList()
        };
        vm.SetProfessionCatalog(catalog);   // moves the listed IDs into check boxes, leaving the unknown ones in _extraProfessions
        foreach (var c in m.Components) vm.Components.Add(ComponentSlotVm.FromModel(c, t));
        foreach (var r in m.Resources) vm.Resources.Add(ResourceSlotVm.FromModel(r, t));
        foreach (var e in m.Experiments) vm.Experiments.Add(ExperimentVm.FromModel(e, t));
        return vm;
    }

    public Schematic ToModel()
    {
        var m = new Schematic
        {
            Id = Id.Trim(), Name = Name.Trim(),
            Category = string.IsNullOrWhiteSpace(_category) ? null : _category.Trim(),
            Complexity = _complexity, Size = _size,
            ShowOverride = _showIndex switch { 1 => true, 2 => false, _ => null },
        };
        m.Professions.AddRange(SelectedProfessionIds());
        foreach (var c in Components) m.Components.Add(c.ToModel());
        foreach (var r in Resources) m.Resources.Add(r.ToModel());
        foreach (var e in Experiments) m.Experiments.Add(e.ToModel());
        return m;
    }
}
