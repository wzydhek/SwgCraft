using System.Text.Json;

namespace SwgCraft.Core;

public sealed record LoadResult<T>(T Value, bool FileExisted, string? Error);
public sealed record SaveResult(bool Saved, IReadOnlyList<ValidationIssue> Issues);

/// <summary>Reads and writes the static JSON files (resources, professions, lootitems, componentclasses, schematics).</summary>
public sealed class StaticDataStore
{
    public string Folder { get; }
    public string ResourcesPath => Path.Combine(Folder, "resources.json");
    public string ProfessionsPath => Path.Combine(Folder, "professions.json");
    public string LootItemsPath => Path.Combine(Folder, "lootitems.json");
    public string ClassesPath => Path.Combine(Folder, "componentclasses.json");
    public string SchematicsPath => Path.Combine(Folder, "schematics.json");

    public StaticDataStore(string folder) => Folder = folder;

    // ------------------------------------------------------------ load

    public LoadResult<ResourceTreeDocument> LoadResources() =>
        Load<ResourceTreeDocument>(ResourcesPath, d => d.SchemaVersion, ResourceTreeDocument.CurrentSchemaVersion);

    public LoadResult<ProfessionsDocument> LoadProfessions() =>
        Load<ProfessionsDocument>(ProfessionsPath, d => d.SchemaVersion, ProfessionsDocument.CurrentSchemaVersion);

    public LoadResult<LootItemsDocument> LoadLootItems() =>
        Load<LootItemsDocument>(LootItemsPath, d => d.SchemaVersion, LootItemsDocument.CurrentSchemaVersion);

    public LoadResult<ComponentClassesDocument> LoadClasses() =>
        Load<ComponentClassesDocument>(ClassesPath, d => d.SchemaVersion, ComponentClassesDocument.CurrentSchemaVersion);

    public LoadResult<SchematicsDocument> LoadSchematics() =>
        Load<SchematicsDocument>(SchematicsPath, d => d.SchemaVersion, SchematicsDocument.CurrentSchemaVersion);

    // ------------------------------------------------------------ validate (against what is saved on disk)

    public List<ValidationIssue> ValidateLootItems(LootItemsDocument doc) => LootItemValidator.Validate(doc);

    /// <summary>Checks class members against the schematics and looted items saved on disk.</summary>
    public List<ValidationIssue> ValidateClasses(ComponentClassesDocument doc)
    {
        var schematics = LoadSchematics();
        var loot = LoadLootItems();
        var issues = new List<ValidationIssue>();
        AddLoadErrors(issues, schematics.Error, loot.Error);
        issues.AddRange(ClassValidator.Validate(doc, schematics.Error == null ? schematics.Value : null, loot.Error == null ? loot.Value : null));
        return issues;
    }

    /// <summary>Checks schematic references against the professions, classes and resource tree saved on disk.</summary>
    public List<ValidationIssue> ValidateSchematics(SchematicsDocument doc)
    {
        var professions = LoadProfessions();
        var classes = LoadClasses();
        var resources = LoadResources();
        var issues = new List<ValidationIssue>();
        AddLoadErrors(issues, professions.Error, classes.Error, resources.Error);
        issues.AddRange(SchematicValidator.Validate(doc, new ProfessionCatalog(professions.Value), classes.Value, new ResourceTree(resources.Value)));
        return issues;
    }

    static void AddLoadErrors(List<ValidationIssue> issues, params string?[] errors)
    {
        foreach (var e in errors)
            if (e != null) issues.Add(new ValidationIssue(Severity.Error, "dep.load", "A file this one depends on could not be read, so references cannot be checked: " + e));
    }

    // ------------------------------------------------------------ save (refuses on errors, so files on disk always load)

    public SaveResult SaveResources(ResourceTreeDocument doc)
    {
        var issues = ResourceTreeValidator.Validate(doc);
        if (issues.Any(i => i.Severity == Severity.Error)) return new SaveResult(false, issues);
        doc.SchemaVersion = ResourceTreeDocument.CurrentSchemaVersion;
        JsonFile.WriteAtomic(ResourcesPath, doc);
        return new SaveResult(true, issues);
    }

    public SaveResult SaveProfessions(ProfessionsDocument doc)
    {
        var issues = ProfessionValidator.Validate(doc);
        if (issues.Any(i => i.Severity == Severity.Error)) return new SaveResult(false, issues);
        doc.SchemaVersion = ProfessionsDocument.CurrentSchemaVersion;
        JsonFile.WriteAtomic(ProfessionsPath, doc);
        return new SaveResult(true, issues);
    }

    public SaveResult SaveLootItems(LootItemsDocument doc)
    {
        var issues = ValidateLootItems(doc);
        if (issues.Any(i => i.Severity == Severity.Error)) return new SaveResult(false, issues);
        doc.SchemaVersion = LootItemsDocument.CurrentSchemaVersion;
        JsonFile.WriteAtomic(LootItemsPath, doc);
        return new SaveResult(true, issues);
    }

    public SaveResult SaveClasses(ComponentClassesDocument doc)
    {
        var issues = ValidateClasses(doc);
        if (issues.Any(i => i.Severity == Severity.Error)) return new SaveResult(false, issues);
        doc.SchemaVersion = ComponentClassesDocument.CurrentSchemaVersion;
        JsonFile.WriteAtomic(ClassesPath, doc);
        return new SaveResult(true, issues);
    }

    public SaveResult SaveSchematics(SchematicsDocument doc)
    {
        var issues = ValidateSchematics(doc);
        if (issues.Any(i => i.Severity == Severity.Error)) return new SaveResult(false, issues);
        doc.SchemaVersion = SchematicsDocument.CurrentSchemaVersion;
        JsonFile.WriteAtomic(SchematicsPath, doc);
        return new SaveResult(true, issues);
    }

    static LoadResult<T> Load<T>(string path, Func<T, int> versionOf, int currentVersion) where T : new()
    {
        if (!File.Exists(path)) return new(new T(), false, null);
        try
        {
            var doc = JsonFile.Read<T>(path);
            if (versionOf(doc) > currentVersion)
                return new(new T(), true, $"{path} has schemaVersion {versionOf(doc)}, newer than this app understands.");
            return new(doc, true, null);
        }
        catch (Exception ex) when (ex is JsonException or IOException or InvalidDataException or UnauthorizedAccessException)
        {
            return new(new T(), true, $"Could not read {path}:\n{ex.Message}");
        }
    }
}
