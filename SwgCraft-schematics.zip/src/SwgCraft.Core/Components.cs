using System.Text.Json.Serialization;

namespace SwgCraft.Core;

// ---------------------------------------------------------------- looted items (lootitems.json)

public sealed class LootItemsDocument
{
    public const int CurrentSchemaVersion = 1;
    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public List<LootItem> Items { get; set; } = new();
}

/// <summary>
/// A looted component. Every looted item carries a serial number and can come in stacks (a stack of N allows a factory run of N-1).
/// Stacks and serials belong to inventory; this file only says which looted items exist. Modifiers are not tracked.
/// </summary>
public sealed class LootItem
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
}

// ---------------------------------------------------------------- component classes (componentclasses.json)

public enum MemberKind { Schematic, LootItem }

public sealed class ClassMember
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public MemberKind Kind { get; set; }
    public string Id { get; set; } = "";
}

public sealed class ComponentClassesDocument
{
    public const int CurrentSchemaVersion = 1;
    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public List<ComponentClass> Classes { get; set; } = new();
}

/// <summary>
/// A set of interchangeable components, e.g. "Blade Vibro Unit" = [Blade Vibro Unit, Advanced Blade Vibro Unit, Light Weight Blade Vibro Unit (loot)].
/// Members are a flat list (no nesting). The first member is the base item.
/// </summary>
public sealed class ComponentClass
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public List<ClassMember> Members { get; set; } = new();
}

// ---------------------------------------------------------------- schematics (schematics.json)

public enum SlotKind { Schematic, Class }

public sealed class SchematicsDocument
{
    public const int CurrentSchemaVersion = 1;
    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public List<Schematic> Schematics { get; set; } = new();
}

public sealed class Schematic
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";

    /// <summary>Profession IDs that can make this schematic (at least one).</summary>
    public List<string> Professions { get; set; } = new();

    public string? Category { get; set; }
    public int? Complexity { get; set; }
    public int? Size { get; set; }

    /// <summary>null = no override (default behaviour); true/false = JnF's "Show Item" flag.</summary>
    public bool? ShowOverride { get; set; }

    public List<ComponentSlot> Components { get; set; } = new();
    public List<ResourceSlot> Resources { get; set; } = new();
    public List<Experiment> Experiments { get; set; } = new();
}

/// <summary>A component the schematic consumes: another schematic's product, or any member of a component class.</summary>
public sealed class ComponentSlot
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public SlotKind Kind { get; set; }

    /// <summary>Schematic ID or class ID, depending on <see cref="Kind"/>.</summary>
    public string Target { get; set; } = "";

    public int Quantity { get; set; } = 1;

    /// <summary>All units must come from one factory run (one shared serial). Only meaningful when Quantity is 2 or more.</summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public bool Identical { get; set; }

    /// <summary>The schematic can be made without this component.</summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingDefault)]
    public bool Optional { get; set; }
}

/// <summary>A resource the schematic consumes. Resource is a resource-tree node ID; an interior node means "any resource below it".</summary>
public sealed class ResourceSlot
{
    public string Resource { get; set; } = "";
    public int Amount { get; set; } = 1;
}

/// <summary>One experimentation line: a label and integer percentages per stat that add up to exactly 100.</summary>
public sealed class Experiment
{
    public string Name { get; set; } = "";
    public SortedDictionary<Stat, int> Weights { get; set; } = new();
}

// ---------------------------------------------------------------- read-only lookups

public sealed class LootCatalog
{
    public static LootCatalog Empty { get; } = new(new LootItemsDocument());
    readonly Dictionary<string, LootItem> _byId = new(StringComparer.Ordinal);
    public LootItemsDocument Document { get; }
    public IReadOnlyList<LootItem> All => Document.Items;
    public LootCatalog(LootItemsDocument d)
    {
        Document = d;
        foreach (var i in d.Items) if (!string.IsNullOrEmpty(i.Id)) _byId.TryAdd(i.Id, i);
    }
    public LootItem? Find(string id) => _byId.GetValueOrDefault(id);
}

public sealed class ClassCatalog
{
    public static ClassCatalog Empty { get; } = new(new ComponentClassesDocument());
    readonly Dictionary<string, ComponentClass> _byId = new(StringComparer.Ordinal);
    public ComponentClassesDocument Document { get; }
    public IReadOnlyList<ComponentClass> All => Document.Classes;
    public ClassCatalog(ComponentClassesDocument d)
    {
        Document = d;
        foreach (var c in d.Classes) if (!string.IsNullOrEmpty(c.Id)) _byId.TryAdd(c.Id, c);
    }
    public ComponentClass? Find(string id) => _byId.GetValueOrDefault(id);
}

public sealed class SchematicCatalog
{
    public static SchematicCatalog Empty { get; } = new(new SchematicsDocument());
    readonly Dictionary<string, Schematic> _byId = new(StringComparer.Ordinal);
    public SchematicsDocument Document { get; }
    public IReadOnlyList<Schematic> All => Document.Schematics;
    public SchematicCatalog(SchematicsDocument d)
    {
        Document = d;
        foreach (var s in d.Schematics) if (!string.IsNullOrEmpty(s.Id)) _byId.TryAdd(s.Id, s);
    }
    public Schematic? Find(string id) => _byId.GetValueOrDefault(id);
}
