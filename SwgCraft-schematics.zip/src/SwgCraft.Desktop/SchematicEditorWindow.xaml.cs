using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Threading;
using SwgCraft.Core;

namespace SwgCraft.Desktop;

public partial class SchematicEditorWindow : Window
{
    sealed record IssueRow(string Text, SchematicVm? Vm);

    readonly ChangeTracker _tracker = new();
    readonly ObservableCollection<SchematicVm> _schematics = new();
    readonly ICollectionView _view;
    readonly DataGridComboBoxColumn _componentCol;
    readonly DataGridComboBoxColumn _resourceCol;
    Dictionary<object, SchematicVm> _map = new(ReferenceEqualityComparer.Instance);

    List<RefOption> _componentOptions = new();
    List<RefOption> _resourceOptions = new();
    List<Profession> _professions = new();

    public SchematicEditorWindow()
    {
        InitializeComponent();

        _view = CollectionViewSource.GetDefaultView(_schematics);
        _view.Filter = o =>
        {
            var f = FilterBox.Text?.Trim() ?? "";
            return f.Length == 0 || ((SchematicVm)o).Name.Contains(f, StringComparison.OrdinalIgnoreCase);
        };
        SchematicList.ItemsSource = _view;

        _componentCol = MakePicker("Component (schematic or class)", "Key");
        ComponentGrid.Columns.Insert(0, _componentCol);
        _resourceCol = MakePicker("Resource", "Resource");
        ResourceGrid.Columns.Insert(0, _resourceCol);
        BuildExperimentColumns();

        _tracker.Changed += () => Title = "Schematics" + (_tracker.Dirty ? " *" : "");
        Activated += (_, _) => RefreshOptions();
        if (!LoadFromDisk()) Loaded += (_, _) => Close();   // never edit on top of a file that failed to load
    }

    static DataGridComboBoxColumn MakePicker(string header, string bindingPath) => new()
    {
        Header = header,
        Width = new DataGridLength(1, DataGridLengthUnitType.Star),
        SelectedValuePath = "Key",
        DisplayMemberPath = "Display",
        SelectedValueBinding = new Binding(bindingPath) { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
    };

    void BuildExperimentColumns()
    {
        foreach (var stat in StatInfo.All)
        {
            ExperimentGrid.Columns.Add(new DataGridTextColumn
            {
                Header = new TextBlock { Text = stat.ToString(), ToolTip = StatInfo.FullName(stat) },
                Width = 52,
                Binding = new Binding(stat.ToString()) { UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged },
            });
        }

        var warn = new Style(typeof(TextBlock));
        var trigger = new DataTrigger { Binding = new Binding("TotalOk"), Value = false };
        trigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Red));
        trigger.Setters.Add(new Setter(TextBlock.FontWeightProperty, FontWeights.Bold));
        warn.Triggers.Add(trigger);
        ExperimentGrid.Columns.Add(new DataGridTextColumn
        {
            Header = "Total",
            Width = 60,
            IsReadOnly = true,
            Binding = new Binding("Total") { Mode = BindingMode.OneWay },
            ElementStyle = warn,
        });
    }

    SchematicVm? Selected => SchematicList.SelectedItem as SchematicVm;

    void SetStatus(string text) => StatusText.Text = text;

    void CommitAll()
    {
        ComponentGrid.CommitEdit(DataGridEditingUnit.Row, true);
        ResourceGrid.CommitEdit(DataGridEditingUnit.Row, true);
        ExperimentGrid.CommitEdit(DataGridEditingUnit.Row, true);
    }

    // ------------------------------------------------------------ picker options

    List<RefOption> BuildComponentOptions()
    {
        var list = new List<RefOption>();
        foreach (var s in Services.StaticData.LoadSchematics().Value.Schematics)
            if (!string.IsNullOrEmpty(s.Id))
                list.Add(new RefOption(ComponentSlotVm.KeyFor(SlotKind.Schematic, s.Id), "Schematic: " + (string.IsNullOrWhiteSpace(s.Name) ? s.Id : s.Name)));
        foreach (var c in Services.StaticData.LoadClasses().Value.Classes)
            if (!string.IsNullOrEmpty(c.Id))
                list.Add(new RefOption(ComponentSlotVm.KeyFor(SlotKind.Class, c.Id), "Class: " + (string.IsNullOrWhiteSpace(c.Name) ? c.Id : c.Name)));
        list.Sort((a, b) => string.Compare(a.Display, b.Display, StringComparison.OrdinalIgnoreCase));
        return list;
    }

    static List<RefOption> BuildResourceOptions()
    {
        var list = new List<RefOption>();
        void Walk(ResourceNode n, string path)
        {
            var here = path.Length == 0 ? n.Name : path + " > " + n.Name;
            if (!string.IsNullOrEmpty(n.Id)) list.Add(new RefOption(n.Id, n.IsLeaf ? here : here + " (any)"));
            if (n.Children != null) foreach (var c in n.Children) Walk(c, here);
        }
        foreach (var root in Services.Tree.Document.Nodes) Walk(root, "");
        return list;   // tree order, so related resources stay together
    }

    static List<Profession> BuildProfessions() => Services.StaticData.LoadProfessions().Value.Professions.ToList();

    static bool SameProfessions(List<Profession> a, List<Profession> b) =>
        a.Select(p => (p.Id, p.Name)).SequenceEqual(b.Select(p => (p.Id, p.Name)));

    /// <summary>Called when the window is activated: picks up classes, schematics, resources or professions edited in other windows.</summary>
    void RefreshOptions()
    {
        var components = BuildComponentOptions();
        var resources = BuildResourceOptions();
        var professions = BuildProfessions();

        bool componentsChanged = !components.SequenceEqual(_componentOptions);
        bool resourcesChanged = !resources.SequenceEqual(_resourceOptions);
        bool professionsChanged = !SameProfessions(professions, _professions);
        if (!componentsChanged && !resourcesChanged && !professionsChanged) return;

        CommitAll();
        if (componentsChanged)
        {
            _componentOptions = components;
            _componentCol.ItemsSource = _componentOptions;
            foreach (var s in _schematics) foreach (var c in s.Components) c.RaiseKey();
        }
        if (resourcesChanged)
        {
            _resourceOptions = resources;
            _resourceCol.ItemsSource = _resourceOptions;
            foreach (var s in _schematics) foreach (var r in s.Resources) r.RaiseResource();
        }
        if (professionsChanged)
        {
            _professions = professions;
            foreach (var s in _schematics) s.SetProfessionCatalog(_professions);
        }
    }

    // ------------------------------------------------------------ load / save

    bool LoadFromDisk()
    {
        var load = Services.StaticData.LoadSchematics();
        if (load.Error != null)
        {
            MessageBox.Show(this, load.Error, "Schematics", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }

        _componentOptions = BuildComponentOptions();
        _resourceOptions = BuildResourceOptions();
        _professions = BuildProfessions();
        _componentCol.ItemsSource = _componentOptions;
        _resourceCol.ItemsSource = _resourceOptions;

        SchematicList.SelectedItem = null;
        _schematics.Clear();
        foreach (var s in load.Value.Schematics) _schematics.Add(SchematicVm.FromModel(s, _professions, _tracker));
        SortInPlace();
        _tracker.Reset();
        IssueList.ItemsSource = null;
        SetStatus(load.FileExisted
            ? $"Loaded {_schematics.Count} schematic(s) from {Services.StaticData.SchematicsPath}"
            : $"No schematics.json yet; it will be created at {Services.StaticData.SchematicsPath}");
        return true;
    }

    void SortInPlace()
    {
        var selected = Selected;
        var sorted = _schematics.OrderBy(s => s.Name, StringComparer.OrdinalIgnoreCase).ToList();
        for (int i = 0; i < sorted.Count; i++)
        {
            int at = _schematics.IndexOf(sorted[i]);
            if (at != i) _schematics.Move(at, i);
        }
        if (selected != null) SchematicList.SelectedItem = selected;
    }

    SchematicsDocument BuildDocument()
    {
        _map = new Dictionary<object, SchematicVm>(ReferenceEqualityComparer.Instance);
        var doc = new SchematicsDocument();
        foreach (var vm in _schematics)
        {
            var m = vm.ToModel();
            _map[m] = vm;
            doc.Schematics.Add(m);
        }
        return doc;
    }

    void ShowIssues(IEnumerable<ValidationIssue> issues)
    {
        var list = issues.OrderByDescending(i => i.Severity).ToList();
        IssueList.ItemsSource = list.Select(i =>
        {
            SchematicVm? vm = null;
            if (i.Subject != null) _map.TryGetValue(i.Subject, out vm);
            return new IssueRow($"{(i.Severity == Severity.Error ? "ERROR" : "warn ")}  {i.Message}", vm);
        }).ToList();
        SetStatus($"{list.Count(i => i.Severity == Severity.Error)} error(s), {list.Count(i => i.Severity == Severity.Warning)} warning(s)");
    }

    bool Save()
    {
        CommitAll();
        var doc = BuildDocument();
        SaveResult result;
        try { result = Services.StaticData.SaveSchematics(doc); }
        catch (IOException ex)
        {
            MessageBox.Show(this, "Could not write schematics.json:\n" + ex.Message, Title, MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }
        ShowIssues(result.Issues);
        if (!result.Saved)
        {
            SetStatus("NOT saved: fix the errors listed below first.");
            return false;
        }
        foreach (var vm in _schematics) vm.IdFollowsName = false;   // saved IDs are frozen
        SortInPlace();
        _tracker.Reset();
        SetStatus($"Saved {DateTime.Now:HH:mm:ss}. " + StatusText.Text);
        return true;
    }

    void Save_Click(object sender, RoutedEventArgs e) => Save();

    void Validate_Click(object sender, RoutedEventArgs e)
    {
        CommitAll();
        ShowIssues(Services.StaticData.ValidateSchematics(BuildDocument()));
    }

    void Reload_Click(object sender, RoutedEventArgs e)
    {
        if (_tracker.Dirty &&
            MessageBox.Show(this, "Discard unsaved changes and reload from disk?", Title,
                            MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;
        LoadFromDisk();
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        CommitAll();
        if (_tracker.Dirty)
        {
            var r = MessageBox.Show(this, "Save changes to the schematics?", "Schematics",
                                    MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (r == MessageBoxResult.Cancel || (r == MessageBoxResult.Yes && !Save())) { e.Cancel = true; return; }
        }
        base.OnClosing(e);
    }

    // ------------------------------------------------------------ schematic list

    void FilterBox_TextChanged(object sender, TextChangedEventArgs e) => _view.Refresh();

    void SchematicList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        Detail.DataContext = Selected;
        Detail.IsEnabled = Selected != null;
    }

    void Add_Click(object sender, RoutedEventArgs e)
    {
        CommitAll();
        FilterBox.Text = "";
        var vm = SchematicVm.CreateNew(_tracker, _professions);
        _schematics.Add(vm);
        SchematicList.SelectedItem = vm;
        SchematicList.ScrollIntoView(vm);
    }

    void Duplicate_Click(object sender, RoutedEventArgs e)
    {
        CommitAll();
        if (Selected is not { } sel) return;
        FilterBox.Text = "";
        var model = sel.ToModel();
        model.Name += " (copy)";
        model.Id = Slug.From(model.Name);
        var vm = SchematicVm.FromModel(model, _professions, _tracker);
        vm.IdFollowsName = true;
        _schematics.Add(vm);
        _tracker.Touch();
        SchematicList.SelectedItem = vm;
        SchematicList.ScrollIntoView(vm);
    }

    void Delete_Click(object sender, RoutedEventArgs e)
    {
        CommitAll();
        if (Selected is not { } sel) return;
        if (MessageBox.Show(this, $"Delete the schematic '{sel.Name}'?\n\nClasses and other schematics that still use it will be flagged the next time they are validated.",
                            Title, MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        _schematics.Remove(sel);
        _tracker.Touch();
    }

    void IssueList_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (IssueList.SelectedItem is IssueRow { Vm: { } vm })
        {
            FilterBox.Text = "";
            SchematicList.SelectedItem = vm;
            SchematicList.ScrollIntoView(vm);
        }
    }

    // ------------------------------------------------------------ slot rows (shared by the three grids)

    void AddRow(DataGrid grid, IList list, object item)
    {
        CommitAll();
        list.Add(item);
        grid.SelectedItem = item;
        grid.ScrollIntoView(item);
        Dispatcher.BeginInvoke(new Action(() =>
        {
            grid.CurrentCell = new DataGridCellInfo(item, grid.Columns[0]);
            grid.BeginEdit();
        }), DispatcherPriority.Background);
    }

    void DeleteRow(DataGrid grid, IList list)
    {
        CommitAll();
        if (grid.SelectedItem is { } item) list.Remove(item);
    }

    void MoveRow(DataGrid grid, IList list, int delta)
    {
        CommitAll();
        if (grid.SelectedItem is not { } item) return;
        int i = list.IndexOf(item), j = i + delta;
        if (i < 0 || j < 0 || j >= list.Count) return;
        list.RemoveAt(i);
        list.Insert(j, item);
        grid.SelectedItem = item;
    }

    void AddComponent_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) AddRow(ComponentGrid, s.Components, new ComponentSlotVm(_tracker)); }
    void DeleteComponent_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) DeleteRow(ComponentGrid, s.Components); }
    void ComponentUp_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) MoveRow(ComponentGrid, s.Components, -1); }
    void ComponentDown_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) MoveRow(ComponentGrid, s.Components, 1); }

    void AddResource_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) AddRow(ResourceGrid, s.Resources, new ResourceSlotVm(_tracker)); }
    void DeleteResource_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) DeleteRow(ResourceGrid, s.Resources); }
    void ResourceUp_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) MoveRow(ResourceGrid, s.Resources, -1); }
    void ResourceDown_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) MoveRow(ResourceGrid, s.Resources, 1); }

    void AddExperiment_Click(object sender, RoutedEventArgs e)
    {
        if (Selected is not { } s) return;
        var vm = new ExperimentVm(_tracker);
        AddRow(ExperimentGrid, s.Experiments, vm);
    }
    void DeleteExperiment_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) DeleteRow(ExperimentGrid, s.Experiments); }
    void ExperimentUp_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) MoveRow(ExperimentGrid, s.Experiments, -1); }
    void ExperimentDown_Click(object sender, RoutedEventArgs e) { if (Selected is { } s) MoveRow(ExperimentGrid, s.Experiments, 1); }
}
