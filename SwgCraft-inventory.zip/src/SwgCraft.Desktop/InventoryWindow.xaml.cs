using System.Windows;
using System.Windows.Controls;
using SwgCraft.Core;
using SwgCraft.Data;

namespace SwgCraft.Desktop;

public sealed record InventoryRow(
    long SpawnId, string Name, string TypeName, int Quantity,
    int? ER, int? CR, int? CD, int? DR, int? FL, int? HR, int? MB, int? PE, int? OQ, int? SR, int? UT,
    string Status, string Note);

public partial class InventoryWindow : Window
{
    public InventoryWindow()
    {
        InitializeComponent();
        Services.ActiveGalaxyChanged += Refresh;
        Services.SpawnDataChanged += Refresh;
        Services.TreeChanged += Refresh;
        Closed += (_, _) =>
        {
            Services.ActiveGalaxyChanged -= Refresh;
            Services.SpawnDataChanged -= Refresh;
            Services.TreeChanged -= Refresh;
        };
        Refresh();
    }

    IGalaxySpawnStore? Store =>
        Services.Settings.ActiveGalaxyId is int gid ? Services.Spawns.ForGalaxy(gid) : null;

    InventoryRow? Selected => InvGrid.SelectedItem as InventoryRow;

    // ------------------------------------------------------------ display

    void Refresh()
    {
        var store = Store;
        if (store == null)
        {
            InvGrid.ItemsSource = null;
            StatusText.Text = "No active galaxy selected.";
            return;
        }

        var keep = Selected?.SpawnId;
        var filter = FilterBox.Text.Trim();
        var all = store.Inventory().Select(ToRow).ToList();
        var rows = all.Where(r => filter.Length == 0
                                  || r.Name.Contains(filter, StringComparison.OrdinalIgnoreCase)
                                  || r.TypeName.Contains(filter, StringComparison.OrdinalIgnoreCase)).ToList();
        InvGrid.ItemsSource = rows;
        InvGrid.SelectedItem = keep == null ? null : rows.FirstOrDefault(r => r.SpawnId == keep);
        StatusText.Text = $"Galaxy {store.GalaxyId}: {rows.Count} of {all.Count} resource stack(s), {rows.Sum(r => (long)r.Quantity):N0} units shown.";
    }

    static InventoryRow ToRow(InventoryItem i)
    {
        var s = i.Spawn;
        var node = Services.Tree.Find(s.ResourceTypeId);
        int? St(Stat stat) => s.Stats.TryGetValue(stat, out var v) ? v : null;
        return new InventoryRow(
            s.Id, s.Name, node?.Name ?? $"{s.ResourceTypeId} (not in tree)", i.Quantity,
            St(Stat.ER), St(Stat.CR), St(Stat.CD), St(Stat.DR), St(Stat.FL), St(Stat.HR),
            St(Stat.MB), St(Stat.PE), St(Stat.OQ), St(Stat.SR), St(Stat.UT),
            s.DespawnedUtc == null ? "Current" : "Despawned " + s.DespawnedUtc.Value.ToLocalTime().ToString("yyyy-MM-dd"),
            i.Note ?? "");
    }

    void Filter_Changed(object sender, TextChangedEventArgs e) { if (IsLoaded) Refresh(); }

    void InvGrid_SelectionChanged(object sender, SelectionChangedEventArgs e) => NoteBox.Text = Selected?.Note ?? "";

    // ------------------------------------------------------------ actions

    void AddResource_Click(object sender, RoutedEventArgs e)
    {
        if (Services.Settings.ActiveGalaxyId is not int gid)
        {
            MessageBox.Show(this, "Select a galaxy first.", Title);
            return;
        }
        if (new AddInventoryWindow(gid) { Owner = this }.ShowDialog() == true) Refresh();
    }

    bool TryAmount(bool allowZero, out int amount)
    {
        if (int.TryParse(AmountBox.Text.Trim(), out amount) && (allowZero ? amount >= 0 : amount > 0)) return true;
        StatusText.Text = allowZero ? "Enter an amount (0 or more) first." : "Enter a positive amount first.";
        return false;
    }

    bool TryTarget(out IGalaxySpawnStore store, out InventoryRow row)
    {
        store = Store!;
        row = Selected!;
        if (Store != null && Selected != null) return true;
        StatusText.Text = "Select a resource stack first.";
        return false;
    }

    void Plus_Click(object sender, RoutedEventArgs e) => Apply(+1);
    void Minus_Click(object sender, RoutedEventArgs e) => Apply(-1);

    void Apply(int sign)
    {
        if (!TryTarget(out var store, out var row) || !TryAmount(false, out var amount)) return;
        if (store.AdjustInventory(row.SpawnId, sign * amount) == null)
        {
            StatusText.Text = $"Cannot use {amount}: only {row.Quantity:N0} of {row.Name} on hand.";
            return;
        }
        AmountBox.Clear();
        Refresh();
    }

    void Set_Click(object sender, RoutedEventArgs e)
    {
        if (!TryTarget(out var store, out var row) || !TryAmount(true, out var amount)) return;
        store.SetInventory(row.SpawnId, amount, row.Note);
        AmountBox.Clear();
        Refresh();
    }

    void Remove_Click(object sender, RoutedEventArgs e)
    {
        if (!TryTarget(out var store, out var row)) return;
        if (MessageBox.Show(this, $"Remove {row.Quantity:N0} of '{row.Name}' from inventory?", Title,
                            MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        store.SetInventory(row.SpawnId, 0, null);
        Refresh();
    }

    void SaveNote_Click(object sender, RoutedEventArgs e)
    {
        if (!TryTarget(out var store, out var row)) return;
        store.SetInventory(row.SpawnId, row.Quantity, NoteBox.Text);   // an empty box clears the note
        Refresh();
    }
}
