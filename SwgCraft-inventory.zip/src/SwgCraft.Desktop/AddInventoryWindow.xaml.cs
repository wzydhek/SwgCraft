using System.Windows;
using System.Windows.Controls;
using SwgCraft.Data;

namespace SwgCraft.Desktop;

public sealed record PickRow(long SpawnId, string Name, string TypeName, string Stats, string Spawned, string Status);

/// <summary>Pick a spawn (name, type and stats are shown so reused names are easy to tell apart) and add a quantity of it.</summary>
public partial class AddInventoryWindow : Window
{
    readonly int _galaxyId;

    public AddInventoryWindow(int galaxyId)
    {
        _galaxyId = galaxyId;
        InitializeComponent();
        Loaded += (_, _) => { Refresh(); SearchBox.Focus(); };
    }

    void Search_Changed(object sender, TextChangedEventArgs e) { if (IsLoaded) Refresh(); }
    void Despawned_Changed(object sender, RoutedEventArgs e) { if (IsLoaded) Refresh(); }

    void Refresh()
    {
        var term = SearchBox.Text.Trim();
        var spawns = Services.Spawns.ForGalaxy(_galaxyId).Spawns(IncludeDespawned.IsChecked != true, null);
        PickGrid.ItemsSource = spawns.Select(s =>
        {
            var node = Services.Tree.Find(s.ResourceTypeId);
            return new PickRow(
                s.Id, s.Name, node?.Name ?? $"{s.ResourceTypeId} (not in tree)",
                string.Join("  ", s.Stats.OrderBy(k => k.Key).Select(k => $"{k.Key} {k.Value}")),
                s.SpawnedUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm"),
                s.DespawnedUtc == null ? "Current" : "Despawned " + s.DespawnedUtc.Value.ToLocalTime().ToString("yyyy-MM-dd"));
        }).Where(r => term.Length == 0
                      || r.Name.Contains(term, StringComparison.OrdinalIgnoreCase)
                      || r.TypeName.Contains(term, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    void Add_Click(object sender, RoutedEventArgs e)
    {
        if (PickGrid.SelectedItem is not PickRow row)
        {
            MessageBox.Show(this, "Select a resource in the list.", Title);
            return;
        }
        if (!int.TryParse(QtyBox.Text.Trim(), out var qty) || qty <= 0)
        {
            MessageBox.Show(this, "Enter a quantity greater than zero.", Title);
            return;
        }
        var note = NoteBox.Text.Trim();
        Services.Spawns.ForGalaxy(_galaxyId).AdjustInventory(row.SpawnId, qty, note.Length == 0 ? null : note);
        DialogResult = true;
    }
}
