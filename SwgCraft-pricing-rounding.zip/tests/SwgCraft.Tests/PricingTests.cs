using SwgCraft.Core;
using SwgCraft.Data;

namespace SwgCraft.Tests;

public class PricingTests
{
    // Defaults: max price 10, weights 0.4/0.3/0.3, thresholds 95%/90% (inclusive), floor 1, one decimal rounded up.
    static readonly PriceSettings Defaults = new();
    const int Precision = 9;

    static IReadOnlyDictionary<Stat, int> S(params (Stat Stat, int Value)[] items) =>
        items.ToDictionary(i => i.Stat, i => i.Value);

    /// <summary>Values in the order ER, CR, CD, DR, FL, HR, MB, PE, OQ, SR, UT; zeros are left out.</summary>
    static IReadOnlyDictionary<Stat, int> ByStat(int[] values) =>
        StatInfo.All.Zip(values).Where(p => p.Second > 0).ToDictionary(p => p.First, p => p.Second);

    static double? Price(IReadOnlyDictionary<Stat, int> stats, IReadOnlyDictionary<Stat, int> maxima) =>
        CpuPrice.Compute(stats, maxima, Defaults);

    [Fact]
    public void Default_settings_are_valid() => Assert.Null(Defaults.Check());

    // Expected numbers come from a cell-by-cell transcription of the JnF formulas, then rounded up to one decimal.

    [Fact]
    public void Two_stat_resource()
    {
        // OQ 960/1000 is above 95%, UT 920/1000 is between 90% and 95%: 9.4 * (0.4 + 0.3*0.5 + 0.3*0.5) = 6.58 -> 6.6
        var price = Price(S((Stat.OQ, 960), (Stat.UT, 920)), S((Stat.OQ, 1000), (Stat.UT, 1000)));
        Assert.Equal(6.6, price!.Value, Precision);
    }

    [Fact]
    public void Three_stats_with_different_maximums()
    {
        var stats = S((Stat.ER, 480), (Stat.CR, 920), (Stat.OQ, 400));
        var maxima = S((Stat.ER, 500), (Stat.CR, 1000), (Stat.OQ, 800));
        Assert.Equal(4.7, Price(stats, maxima)!.Value, Precision);   // 4.6957 rounded up
    }

    [Fact]
    public void A_perfect_resource_only_reaches_seventy_percent_of_the_max_price()
    {
        // As in the sheet: a stat counts in the 95% bucket OR the 90% bucket, never both,
        // so the 0.3 weight of the 90% bucket is unused when every stat is above 95%.
        var price = Price(S((Stat.OQ, 1000), (Stat.UT, 1000)), S((Stat.OQ, 1000), (Stat.UT, 1000)));
        Assert.Equal(7.0, price!.Value, Precision);
    }

    [Theory]
    [InlineData(100, 1.0)]      // 0.4 would be below the floor
    [InlineData(899, 3.6)]      // 3.596 rounded up; just under 90%
    [InlineData(900, 6.3)]      // exactly 90% counts (the sheet itself would not count it)
    [InlineData(901, 6.4)]      // 6.307 rounded up
    [InlineData(949, 6.7)]
    [InlineData(950, 6.7)]      // exactly 95%: top bucket; equal weights make the price the same as the 90% bucket
    [InlineData(951, 6.7)]
    [InlineData(1000, 7.0)]
    public void Single_stat_thresholds_are_inclusive(int oq, double expected) =>
        Assert.Equal(expected, Price(S((Stat.OQ, oq)), S((Stat.OQ, 1000)))!.Value, Precision);

    [Theory]
    [InlineData(300, 1.2)]      // raw value is 1.2000000000000002; a plain ceiling would give 1.3
    [InlineData(600, 2.4)]      // raw 2.4000000000000004
    [InlineData(700, 2.8)]      // raw 2.8000000000000003
    public void Floating_point_noise_does_not_push_an_exact_price_up(int oq, double expected) =>
        Assert.Equal(expected, Price(S((Stat.OQ, oq)), S((Stat.OQ, 1000)))!.Value, Precision);

    [Fact]
    public void Exactly_95_percent_counts_as_the_top_bucket()
    {
        // With unequal weights the two buckets differ: top = 0.4 + 0.4, 90% bucket = 0.4 + 0.2.
        var settings = new PriceSettings { WeightStatTotals = 0.4, WeightHigh = 0.2, WeightTop = 0.4 };
        var price = CpuPrice.Compute(S((Stat.OQ, 950)), S((Stat.OQ, 1000)), settings);
        Assert.Equal(7.6, price!.Value, Precision);
    }

    [Fact]
    public void Missing_data_gives_no_price()
    {
        Assert.Null(Price(S(), S((Stat.OQ, 1000))));                        // no stats
        Assert.Null(Price(S((Stat.OQ, 0)), S((Stat.OQ, 1000))));            // stats are all 0
        Assert.Null(Price(S((Stat.OQ, 500)), S()));                         // no maximums
        Assert.Null(Price(S((Stat.OQ, 500)), S((Stat.OQ, 0))));
    }

    [Fact]
    public void Weights_must_add_up_to_one()
    {
        Assert.NotNull(new PriceSettings { WeightHigh = 0.4 }.Check());
        Assert.Null(new PriceSettings { WeightStatTotals = 0.5, WeightHigh = 0.2, WeightTop = 0.3 }.Check());
    }

    [Fact]
    public void Bad_thresholds_prices_and_rounding_are_rejected()
    {
        Assert.NotNull(new PriceSettings { HighThreshold = 0.96 }.Check());   // above the top threshold
        Assert.NotNull(new PriceSettings { TopThreshold = 1.2 }.Check());
        Assert.NotNull(new PriceSettings { MaxPrice = 0 }.Check());
        Assert.NotNull(new PriceSettings { MinPrice = -1 }.Check());
        Assert.NotNull(new PriceSettings { Decimals = 5 }.Check());
        Assert.NotNull(new PriceSettings { Decimals = -1 }.Check());
        Assert.NotNull(new PriceSettings { Rounding = "sideways" }.Check());
        Assert.Null(new PriceSettings { Rounding = "Nearest" }.Check());      // not case sensitive
    }

    // ------------------------------------------------------------ the three worked examples from the sheet

    [Theory]
    [InlineData("aokiaism, Vendusii Crystal Amorphous Gemstone",
        new[] { 643, 770, 0, 786, 0, 936, 491, 0, 127, 914, 929 },
        new[] { 744, 930, 0, 930, 0, 972, 558, 0, 1000, 930, 930 }, 4.1, 4.2)]
    [InlineData("oideaium, Platinite Copper",
        new[] { 0, 629, 912, 594, 0, 548, 906, 0, 678, 734, 731 },
        new[] { 0, 738, 961, 646, 0, 615, 961, 0, 1000, 761, 761 }, 5.2, 5.3)]
    [InlineData("febeboo, Crystallized Bicorbantium Steel",
        new[] { 0, 493, 255, 666, 0, 543, 702, 0, 44, 238, 505 },
        new[] { 0, 1000, 1000, 1000, 0, 1000, 1000, 0, 1000, 1000, 1000 }, 1.7, 1.8)]
    public void JnF_sheet_examples(string resource, int[] stats, int[] maxima, double sheetValue, double roundedUp)
    {
        // The sheet shows one decimal, rounded to nearest, so "nearest" must reproduce its numbers...
        var nearest = CpuPrice.Compute(ByStat(stats), ByStat(maxima), new PriceSettings { Rounding = "nearest" });
        Assert.Equal(sheetValue, nearest!.Value, 6);

        // ...and the default (always round up) is the same price rounded up instead.
        Assert.Equal(roundedUp, Price(ByStat(stats), ByStat(maxima))!.Value, 6);
    }

    [Theory]
    [InlineData("up", 1, 4.2)]          // raw 4.100586 for the first example above
    [InlineData("nearest", 1, 4.1)]
    [InlineData("up", 2, 4.11)]
    [InlineData("nearest", 2, 4.1)]
    [InlineData("up", 0, 5.0)]
    public void Rounding_modes_and_decimals(string mode, int decimals, double expected)
    {
        var stats = ByStat(new[] { 643, 770, 0, 786, 0, 936, 491, 0, 127, 914, 929 });
        var maxima = ByStat(new[] { 744, 930, 0, 930, 0, 972, 558, 0, 1000, 930, 930 });
        var settings = new PriceSettings { Rounding = mode, Decimals = decimals };
        Assert.Equal(expected, CpuPrice.Compute(stats, maxima, settings)!.Value, 6);
    }

    [Fact]
    public void Rounding_none_returns_the_sheets_raw_value()
    {
        var stats = ByStat(new[] { 643, 770, 0, 786, 0, 936, 491, 0, 127, 914, 929 });
        var maxima = ByStat(new[] { 744, 930, 0, 930, 0, 972, 558, 0, 1000, 930, 930 });
        var price = CpuPrice.Compute(stats, maxima, new PriceSettings { Rounding = "none" });
        Assert.Equal(4.100586, price!.Value, 6);
    }

    [Fact]
    public void RoundPrice_applies_the_same_rule_to_typed_values()
    {
        Assert.Equal(4.3, CpuPrice.RoundPrice(4.25, Defaults), Precision);
        Assert.Equal(4.2, CpuPrice.RoundPrice(4.2, Defaults), Precision);
        Assert.Equal(4.2, CpuPrice.RoundPrice(4.2000000000000002, Defaults), Precision);
    }

    // ------------------------------------------------------------ calculator over the resource tree

    static Spawn MakeSpawn(IReadOnlyDictionary<Stat, int> stats)
    {
        var now = new DateTimeOffset(2026, 10, 6, 0, 0, 0, TimeSpan.Zero);
        return new Spawn(1, 118, "alpha", "t", stats, now, now, now, null, "");
    }

    static ResourceNode Leaf(params (Stat Stat, int Max)[] maxima) => new()
    {
        Id = "t", Name = "T",
        Ranges = maxima.ToDictionary(m => m.Stat, m => new StatRange { Min = 1, Max = m.Max }).ToSorted(),
    };

    [Fact]
    public void Calculator_uses_the_type_maximums_from_the_tree()
    {
        var calc = new JnfUnitPriceCalculator(() => new PriceSettings());
        var spawn = MakeSpawn(S((Stat.OQ, 960), (Stat.UT, 920)));
        Assert.Equal(6.6, calc.Calculate(spawn, Leaf((Stat.OQ, 1000), (Stat.UT, 1000)))!.Value, Precision);
    }

    [Fact]
    public void Calculator_returns_nothing_for_unknown_types_or_invalid_settings()
    {
        var spawn = MakeSpawn(S((Stat.OQ, 960)));
        var good = new JnfUnitPriceCalculator(() => new PriceSettings());
        Assert.Null(good.Calculate(spawn, null));
        Assert.Null(good.Calculate(spawn, new ResourceNode { Id = "t", Name = "T" }));   // no ranges

        var broken = new JnfUnitPriceCalculator(() => new PriceSettings { WeightTop = 0.9 });
        Assert.Null(broken.Calculate(spawn, Leaf((Stat.OQ, 1000))));
    }

    // ------------------------------------------------------------ settings file and highlighting

    [Fact]
    public void Old_settings_files_without_pricing_still_load_with_defaults()
    {
        var path = Path.Combine(Path.GetTempPath(), $"swgcraft-{Guid.NewGuid():N}.json");
        try
        {
            File.WriteAllText(path, """{ "schemaVersion": 1, "activeGalaxyId": 118 }""");
            var s = JsonFile.Read<AppSettings>(path);
            Assert.Equal(10, s.Pricing.MaxPrice);
            Assert.Equal(1, s.Pricing.Decimals);
            Assert.Equal("up", s.Pricing.Rounding);
            Assert.Null(s.Pricing.Check());

            s.Pricing.MaxPrice = 12;
            s.Pricing.Rounding = "nearest";
            JsonFile.WriteAtomic(path, s);
            var back = JsonFile.Read<AppSettings>(path);
            Assert.Equal(12, back.Pricing.MaxPrice);
            Assert.Equal("nearest", back.Pricing.Rounding);
        }
        finally { File.Delete(path); File.Delete(path + ".bak"); }
    }

    [Fact]
    public void Highlight_thresholds_can_be_changed()
    {
        Assert.Equal(0, StatQuality.Tier(850, 1000));
        Assert.Equal(1, StatQuality.Tier(850, 1000, 0.85, 0.95));
        Assert.Equal(2, StatQuality.Tier(980, 1000, 0.85, 0.98));
    }
}

static class PricingTestExtensions
{
    public static SortedDictionary<Stat, StatRange> ToSorted(this Dictionary<Stat, StatRange> d) => new(d);
}
